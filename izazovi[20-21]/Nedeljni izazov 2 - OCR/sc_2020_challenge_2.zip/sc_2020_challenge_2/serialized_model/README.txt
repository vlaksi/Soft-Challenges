U ovaj folder sacuvati serijalozovani model u slucaju da ste koristili serijalizaciju.

Platforma ne vrsi download "dataset" foldera, posto njega studenti nece modifikovati (statican je), ali ce vrsiti download "serialized_model" foldera. Zbog toga je u njega potrebno sacuvati fajlove vec istreniranih modela.
